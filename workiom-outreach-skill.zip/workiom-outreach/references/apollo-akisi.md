# Üretim akışı: sektör adından onaya

Kullanıcı "lojistik" (ya da başka bir sektör) dediğinde bu 6 adımı sırayla
izle. Her adımın sonunda kısa durum ver; 4. adımda dur ve onay bekle.

## Adım 1 · Departman planı
`references/departman-matrisi.md`'den sektörün departmanlarını listele.
Kullanıcı belirli departmanlar söylediyse sadece onları al. Planı tek tabloyla
göster (departman, kime, ana use case, kanıt) ve "[KANIT ZAYIF]" / "[TEYİT]"
satırlarını belirt. Kullanıcı itiraz etmezse devam et.

## Adım 2 · Apollo'dan kontak çek
```
python scripts/apollo_cek.py --sektor <sektor>
```
Önce zenginleştirme olmadan çalıştır. Çıkan `ozet.md`'yi göster. E-posta açmak
kredi harcar; `--zenginlestir` için kullanıcıdan açık onay al ve kaç kişi
açılacağını söyle.

Sonra her CSV'de:
- **hitap** sütununu doldur: "Ad Bey" / "Ad Hanım". Cinsiyetten emin
  olmadığın isimlerde boş bırak ve listele (ör. Deniz, Evren, Umut).
- Unvanı departmanla uyuşmayanları (ör. "Teknik Müdür" ama BT'ci) ayıkla,
  ayrı bir `ayiklananlar.csv`'ye koy.
- Firmanın sahipliği kurucu/aile ise not düş; o firmanın patronu yatay
  kurucu sekansına aday.

## Adım 3 · Sekansları yaz
Her departman için `SKILL.md` §4'e göre D1-D3 yaz, `references/ornek-sekans.md`
ayarında. Dosya: `cikti/<sektor>/<tarih>/sekans_<departman>.md`.
Yazınca her sekansı SKILL.md §3'teki testle kontrol et (başka departmana
gönderilebiliyor mu?) ve §6 doğruluk kurallarına bak.

Kişiselleştirme: her kontak için firmanın web sitesinden ya da Apollo
verisinden doğrulanabilen tek bir cümle yaz, CSV'nin `kisisellestirme`
sütununa koy. Firma başına bir kez araştır, aynı firmadaki kişilerde
departmana göre uyarla. Doğrulayamadığını boş bırak.

## Adım 4 · Onay paketi (DUR)
Kullanıcıya tek mesajda göster:
- Departman bazlı sayılar (kişi, firma, e-postalı, hitabı boş, kişiselleştirmesi boş)
- Her departmanın D1'i tam metin; D2-D3 dosyada
- İşaretli riskler ([KANIT ZAYIF], [TEYİT], ayıklananlar)
Sonra: "Yalçın, {sektör} için {N} departman, {K} kişi hazır. Bakıp
onaylıyor musun?" Kullanıcı düzeltme isterse uygula, tekrar göster.

## Adım 5 · Apollo içe aktarma dosyaları
Onaydan sonra her departman için `apollo_import_<departman>.csv` üret:
sütunlar `first_name, last_name, title, company, email, website, linkedin_url,
hitap, kisisellestirme, departman`. Sekans metnini Apollo değişkenlerine çevir:
`{Hitap}` → `{{hitap}}`, `{Kişiselleştirme}` → `{{kisisellestirme}}`,
`{Şirket}` → `{{company}}`. `{Gün} veya {gün}` kısmını kullanıcıya sor ya da
"bu hafta veya önümüzdeki hafta" olarak yaz.

## Adım 6 · Kullanıcının Apollo'da yapacakları (ona listele)
1. Apollo'da bir kerelik iki özel kişi alanı aç: `hitap`, `kisisellestirme`.
   (Settings → Objects/Fields; adı Apollo arayüzünde farklı olabilir.)
2. Her departman CSV'sini içe aktar, bir listeye koy
   (ör. "Lojistik – Filo-Bakım – Ekim").
3. Departman başına bir sekans oluştur, D1-D3'ü yapıştır, gün aralığı
   2 / 6 / 13. Değişkenlerin önizlemede dolduğunu kontrol et.
4. Listeyi sekansa ekle, gönderim hesabını seç, **launch**.

Gönderimi her zaman kullanıcı yapar; sen launch etmezsin.
