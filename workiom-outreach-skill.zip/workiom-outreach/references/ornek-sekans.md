# Örnek sekans — üslup çıpası

Yeni bir departman sekansı yazmadan önce bunu oku. Ritmi, uzunluğu ve
somutluğu bundan al; cümleleri kopyalama.

## Lojistik · Filo ve Bakım Müdürü

**D1 · Gün 2 · Konu: Bakım talebi hangi onayda?**

Merhaba {Hitap}, nasılsınız? Her şey yolundadır umarım 🙏🏻

{Kişiselleştirme}

Filo sisteminiz aracı, kilometreyi ve masrafı kayıt altına alıyor. Ama bir arıza
bildiriminin kimde olduğu, yedek parça talebinin hangi onayda beklediği ya da bu
ay hangi aracın muayenesinin ve sigortasının dolduğu çoğu zaman telefon,
WhatsApp ve Excel arasında kalıyor. Araç yolda kaldığında en çok vakit de bu
boşlukta kayboluyor.

Workiom bir AI-First Workspace. Sistemleriniz ne olduğunu kaydediyor, Workiom
bundan sonra ne olacağını yönetiyor. Arıza bildiriminden iş emrine, parça
onayından lastik değişimine kadar bakım ekibiniz işini tek bir çalışma alanında
yürütüyor; yapay zekâ da ilk günden hepsini görüyor ve iş yapabiliyor. CE LINE
Lojistik, tamir-bakım ve lastik yönetimini araç-makine-personel planlamasıyla
aynı ortamda yürütüyor.

Bakım tarafındaki bir sürecinizle ilk uygulamayı 30 dakikalık bir görüşmede
birlikte kuralım mı?

**D2 · Gün 6 · Konu: Re: Bakım talebi hangi onayda?**

Merhaba {Hitap}, nasılsınız? Her şey yolundadır umarım 🙏🏻

Ekibinizde biri muhtemelen bir arıza kodunu ya da bir servis teklifini bir AI
aracıyla çözüyor. Ama o çözüm, aynı arıza bir sonraki araçta çıktığında
atölyedeki diğer kişinin göreceği bir yerde kalmıyor.

Workiom'da asistanımız Mila'ya "bu ay muayenesi ve sigortası dolan araçlar
hangileri?" diye soruyorsunuz, cevaptan doğrudan görev oluşturup ilgili kişiye
atıyorsunuz. Yaklaşan bakımların takibini bir AI ajanına bırakabiliyorsunuz;
ajan neyi ne zaman yaptığını kayıt altında tutuyor, neye yetkisi olduğunu siz
belirliyorsunuz.

{{company}}'de bir aracın bakım geçmişini bugün kaç farklı yerden topluyorsunuz?

**D3 · Gün 13 · Konu: {{company}} için ilk uygulama**

Merhaba {Hitap}, nasılsınız? Her şey yolundadır umarım 🙏🏻

Önerim büyük bir proje değil, tek bir süreç: arıza bildirimi ve iş emri,
periyodik bakım takvimi ya da lastik takibi. İlk uygulamayı görüşmede birlikte
kuralım, ekibiniz ücretsiz bir pilotla kendi işinde denesin.

CE LINE'da olduğu gibi aynı çalışma alanı zamanla bakımdan operasyona ve satın
almaya yayılıyor, her yeni süreç için yeniden kurulum gerekmiyor. Altyapı
yatırımı yok; kullanıcı başına ödüyorsunuz, süreç sayısı bedeli değiştirmiyor.

{Gün} veya {gün} 30 dakikanız olur mu? Şu an önceliğiniz değilse bu konudaki
son e-postam; ileride gündeme gelirse bu mesaja cevap vermeniz yeterli.

---

## Neden iyi (kontrol listesi)

- D1'in ilk cümlesi departmanın kendi kayıt sistemini anıyor (filo sistemi).
- Boşlukta kalan iş üç somut örnekle anlatılıyor; hepsi bu departmana ait.
- Kanıt departman düzeyinde: CE LINE'ın *tamir-bakım ve lastik* yönetimi.
- Mila sorusu bakım müdürünün gerçekten soracağı bir soru.
- D3'teki üç aday süreç yine sadece bakımdan.
- Bu D1 lojistik İK müdürüne gönderilemez → yeterince özel.

## Kişiselleştirme cümlesi örnekleri

- "{{company}}'nin Gebze'deki yeni aktarma merkezini gördüm; filo büyürken bakım
  takibinin de büyüdüğünü tahmin ediyorum."
- "LinkedIn'de filonuza elektrikli araç eklediğinizi paylaşmışsınız."
Doğrulanamayan bilgiyle cümle kurma; boş bırak, Yalçın doldurur.
