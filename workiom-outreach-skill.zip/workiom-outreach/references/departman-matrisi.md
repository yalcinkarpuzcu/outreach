# Sektör × Departman Matrisi

Her sektörde hedef departmanlar, kime gidileceği, departmanın kayıt sistemi,
o departmana özel use case'ler ve kanıt. Kullanıcı bir sektör söylediğinde o
sektörün TÜM satırları için ayrı sekans üretilir. Unvan listeleri
`config/sektorler.json` ile aynıdır; birini değiştirirsen diğerini de güncelle.

"Kayıt sistemi" sütunu D1'in ilk cümlesinde kullanılır: "{kayıt sistemi}
ne olduğunu kaydediyor, ama..."

## İçindekiler
1. Lojistik · 2. Perakende · 3. Otomotiv · 4. Üretim ve sanayi · 5. Gıda ve
içecek · 6. Gayrimenkul ve inşaat · 7. Enerji · 8. Turizm ve otelcilik ·
9. Özel sağlık · 10. Aile holdingleri · 11. İlaç, medikal ve kozmetik

---

## 1. Lojistik

| Departman | Kime | Kayıt sistemi | Use case'ler | Kanıt |
|---|---|---|---|---|
| operasyon | Operasyon Müdürü/Direktörü, Depo Müdürü | TMS / WMS | Sefer sonrası hasar ve şikâyet dosyası, günlük icmal, araç-makine-personel planlama, müşteri bazlı operasyon talepleri | CE LINE (operasyon, planlama, günlük icmal) |
| filo-bakim | Filo Müdürü, Bakım/Teknik Müdür, Atölye Şefi | Filo / araç takip sistemi | Arıza bildirimi → iş emri, yedek parça onayı, periyodik bakım, lastik takibi, sigorta-muayene-ceza tarihleri | CE LINE (tamir-bakım, lastik), Emlak Konut (araç sigorta, ceza, bakım) |
| kalite | Kalite Müdürü, KYS Sorumlusu | ISO dokümanları / Excel | Uygunsuzluk ve DÖF takibi, müşteri denetim bulguları, iç denetim, sertifika ve resmi evrak süreleri | CE LINE (kalite), EK Asansör (kalite, sertifika, resmi evrak) |
| satin-alma | Satın Alma Müdürü | ERP satın alma modülü | Talep → teklif → onay zinciri, tedarikçi teklif karşılaştırma, tedarikçi performansı | CE LINE (satın alma talep/onay), Ebrar (teklif toplama) |
| ik | İK Müdürü, İK İş Ortağı | Bordro / PDKS | Sezonluk ve dış kaynak işgücü, sürücü belge ve SRC takibi, özlük, izin, işe alım ve oryantasyon | CE LINE (İK özlük ve izin), Doğuş Çay (dış kaynak işgücü, oryantasyon) |
| musteri | Müşteri Hizmetleri Müdürü, Key Account Müdürü | CRM | Müşteri talep ve SLA takibi, periyodik müşteri raporlaması, şikâyetin operasyona devri | CE LINE (satış ve müşteri yönetimi), EK Asansör (müşteri iletişimi, periyodik raporlama) |
| finans | Mali İşler Müdürü, Finans Müdürü | ERP / muhasebe | Taşeron ve araç hakedişleri, fatura onayı, nakit planı hatırlatmaları | CE LINE (finansal plan ve hatırlatmalar), Doğuş Çay (hakediş) [KANIT ZAYIF: lojistikte hakediş doğrudan yok] |

## 2. Perakende

Dil: "mağaza", "bölge", "şube". Zincir mağazacılık, e-ticaret + fiziksel.

| Departman | Kime | Kayıt sistemi | Use case'ler | Kanıt |
|---|---|---|---|---|
| magaza-operasyon | Mağaza Operasyon Müdürü/Direktörü, Bölge Müdürü | POS / ERP | Açılış-kapanış kontrol listeleri, günlük kasa-stok-vitrin kontrolleri, bölge müdürü ziyaret raporu, mağazadan merkeze talepler | Altılar (saha ekipleri, denetim), Ebrar (şube operasyonu) |
| kalite-denetim | Mağaza Denetim Müdürü, Kalite/Standartlar Müdürü | Denetim formları / Excel | Mağaza standartlarına uygunluk, gizli müşteri raporları, bulgudan aksiyona takip, tekrar eden bulgular | Altılar (denetim) · [TEYİT] Renault 13 bölge servis denetimi |
| magaza-gelistirme | Mağaza Geliştirme / Yeni Mağaza Müdürü, Yapı-Proje Müdürü | Proje Excel'leri | Yeni mağaza açılış planı, AVM ile devir-teslim, fit-out ve taşeron takibi, açılış kontrol listesi | Emaar AVM (devir-teslim, fit-out — AVM tarafından aynı süreç) |
| teknik | Teknik Hizmetler Müdürü, Bakım Müdürü | Telefon / e-posta | Mağaza arıza talepleri, servis firması yönlendirme, ekipman bakım takvimi, arızanın kapanış onayı | Ebrar (şube teknik arıza ve servis), Bella Maison (ticket/arıza) |
| ik | İK Müdürü, Mağaza İK Müdürü | Bordro / PDKS | Mağaza personeli işe alım, vardiya ve puantaj, eğitim ve oryantasyon, yüksek devir hızı | Ebrar (işe alım), Tatilbudur (puantaj), Altılar (İK) |
| satin-alma | Satın Alma Müdürü, Kategori Müdürü | ERP | Teklif toplama, tedarikçi geri bildirimi, sarf ve demirbaş talepleri | Ebrar (satın alma, teklif toplama) |
| pazarlama | Pazarlama Müdürü, CRM/Kampanya Müdürü | E-posta / sosyal medya araçları | Kampanya takvimi, mağaza POP materyali dağıtımı, sosyal medya ve influencer planı | VeraClinic (kampanya, influencer), Kar Porselen (kampanya), Ebrar (sosyal medya) |
| musteri-deneyimi | Müşteri Hizmetleri / Deneyim Müdürü, E-ticaret Operasyon Müdürü | CRM / e-ticaret altyapısı | Online sipariş sorunları, müşteri şikâyetinin mağazaya ya da depoya devri, iade süreçleri | Ebrar (online sipariş), Bella Maison (müşteri destek) |

## 3. Otomotiv

İki alt segment: **yan sanayi** (üretici) ve **bayi/servis/distribütör**. Apollo
listesinde firma tipine göre hangi satırların geçerli olduğunu ayır.

| Departman | Alt segment | Kime | Kayıt sistemi | Use case'ler | Kanıt |
|---|---|---|---|---|---|
| kalite | Yan sanayi | Kalite Müdürü, Müşteri Kalite Mühendisi | ERP kalite modülü / Excel | OEM şikâyeti ve 8D takibi, müşteri denetim bulguları, sertifika ve resmi evrak süreleri | EK Asansör (kalite, sertifika, resmi evrak) |
| satin-alma | Yan sanayi | Satın Alma / Tedarik Zinciri Müdürü | ERP | Tedarikçi ziyaret ve performansı, fason üretim takibi, teklif ve onay | EK Asansör (tedarikçi ziyaret, fason) |
| uretim | Yan sanayi | Üretim Müdürü, Üretim Planlama Müdürü | ERP / MES | Üretim talepleri, hat takibi, plan değişikliğinin ekiplere dağıtımı | EK Asansör (üretim planlama, hat izleme, üretim talep) |
| bakim | Yan sanayi | Bakım Müdürü | ERP bakım modülü / Excel | Arıza talebi → iş emri, yedek parça, periyodik bakım | EK Asansör (yedek parça), CE LINE (tamir-bakım) |
| ik | Her ikisi | İK Müdürü | Bordro / PDKS | Vardiya, eğitim-yetkinlik, dış kaynak işgücü, işe giriş-çıkış | Doğuş Çay (dış kaynak), EK Asansör (özlük) |
| servis | Bayi/servis | Servis Müdürü, Satış Sonrası Müdürü | DMS | Servis ağı denetimleri, müşteri şikâyeti ve geri dönüş, yedek parça talepleri | [TEYİT] Renault (13 bölge servis denetimi), EK Asansör (yedek parça) |
| satis | Bayi/servis | Satış Müdürü, Filo Satış Müdürü | DMS / CRM | Saha ve filo satış ekibi takibi, teklif takibi, müşteri memnuniyeti | Altılar (saha satış, müşteri memnuniyeti) |
| bayi-gelistirme | Distribütör | Bayi Geliştirme / Bayi Ağı Müdürü | Excel / e-posta | Bayi denetimi, bayiden gelen talepler, bayi portalı (Vibe Apps) | Altılar (denetim) [KANIT ZAYIF] |

## 4. Üretim ve sanayi

| Departman | Kime | Kayıt sistemi | Use case'ler | Kanıt |
|---|---|---|---|---|
| uretim | Üretim Müdürü, Fabrika Müdürü, Planlama Müdürü | ERP / MES | Üretim talepleri, hat izleme, fason üretim takibi, plan değişikliği | EK Asansör (üretim planlama, hat izleme, fason, üretim talep) |
| kalite | Kalite Müdürü | ERP / ISO dokümanları | Müşteri şikâyeti, uygunsuzluk ve DÖF, sertifika ve resmi evrak, denetim hazırlığı | EK Asansör (kalite, sertifika, resmi evrak) |
| bakim | Bakım Müdürü, Teknik Müdür | ERP bakım / Excel | Arıza → iş emri, yedek parça, periyodik bakım | EK Asansör (yedek parça), CE LINE (tamir-bakım) |
| satin-alma | Satın Alma Müdürü | ERP | Tedarikçi ziyareti ve değerlendirmesi, teklif toplama, onay zinciri | EK Asansör (tedarikçi ziyaret), Doğuş Çay (tedarikçi yönetimi), Ebrar (teklif toplama) |
| arge | Ar-Ge Müdürü, Ürün Geliştirme Müdürü | PLM / Excel | Yeni ürün projeleri, numune ve 3D talepleri, ürün portföyü | Kar Porselen (ürün geliştirme, yeni ürün, portföy), EK Asansör (Ar-Ge, 3D talep) |
| isg | İSG Müdürü, İş Güvenliği Uzmanı | Excel / kâğıt | Ramak kala bildirimleri, saha denetimi bulguları, eğitim ve belge süreleri | Emlak Konut (İSG) |
| ik | İK Müdürü | Bordro / PDKS | Mavi yaka işe alım ve oryantasyon, dış kaynak işgücü, özlük | Doğuş Çay (işe alım/oryantasyon, dış kaynak), EK Asansör (özlük) |
| satis | Satış Müdürü, İhracat Müdürü | CRM / ERP | Müşteri talepleri ve sipariş takibi, periyodik müşteri raporlaması | EK Asansör (satış ve müşteri yönetimi, periyodik raporlama) |

## 5. Gıda ve içecek

| Departman | Kime | Kayıt sistemi | Use case'ler | Kanıt |
|---|---|---|---|---|
| kalite | Kalite / Gıda Güvenliği Müdürü | ISO 22000 / BRC dokümanları | Uygunsuzluk ve DÖF, müşteri ve zincir market denetimleri, sertifika süreleri | EK Asansör (kalite, sertifika) [KANIT ZAYIF: gıdada doğrudan yok] |
| tedarik | Satın Alma / Tedarik Müdürü, Hammadde Müdürü | ERP | Tedarikçi yönetimi ve performansı, hakediş, maliyet takibi | Doğuş Çay (tedarikçi, hakediş, maliyet) |
| uretim | Üretim / Fabrika Müdürü | ERP | Üretim planı değişiklikleri, hat talepleri | EK Asansör (üretim planlama) |
| sube-operasyon | Şube / Bayi Operasyon Müdürü | POS / ERP | Şube teknik arızaları, online sipariş, şube kontrol listeleri | Ebrar (şube teknik arıza, online sipariş) |
| dagitim-filo | Lojistik / Dağıtım Müdürü, Filo Müdürü | Filo sistemi | Dağıtım araçları sigorta-muayene-bakım, rota sorunları | Doğuş Çay (filo), Ebrar (araç filosu sigorta, muayene) |
| ik | İK Müdürü | Bordro / PDKS | Sezonluk ve dış kaynak işgücü, işe alım ve oryantasyon | Doğuş Çay (işe alım/oryantasyon, dış kaynak), Ebrar (işe alım) |
| pazarlama | Pazarlama / Marka Müdürü | Ajans e-postaları | Yeni ürün lansmanı, kampanya planı, portföy | Kar Porselen (yeni ürün, kampanya, portföy) |

## 6. Gayrimenkul ve inşaat

| Departman | Kime | Kayıt sistemi | Use case'ler | Kanıt |
|---|---|---|---|---|
| proje-insaat | Proje Müdürü, Şantiye Şefi, Yapı Denetim Müdürü | ERP / proje Excel'leri | İnşaat süreç takibi, saha talepleri ve onaylar, ilerleme raporu | Emlak Konut (inşaat takibi, saha talep/onay) |
| ihale-satin-alma | İhale Müdürü, Satın Alma Müdürü | ERP | İhale ve teklif yönetimi, taşeron takibi, hakediş | Emlak Konut (ihale, taşeron), Zorlu (hakediş) |
| isg | İSG Müdürü | Excel | Şantiye denetim bulguları, taşeron İSG belgeleri | Emlak Konut (İSG) |
| avm-kiralama | AVM Müdürü, Kiralama Müdürü, Kiracı İlişkileri | Kira / muhasebe sistemi | Kiracı talepleri, devir-teslim, fit-out takibi, kira sözleşmeleri | Emaar AVM (kiracı, devir-teslim, fit-out), Almosa (Royal Mall sözleşme ve kira) |
| tesis-teknik | Tesis Yönetimi / Teknik Müdür | Telefon / Excel | Bakım talepleri, servis firmaları, periyodik bakım | Almosa (Royal Mall bakım) |
| satis-musteri | Satış Müdürü, Müşteri İlişkileri Müdürü | CRM | Alıcı geri bildirimi ve şikâyetleri, teslim sonrası talepler | Emlak Konut (müşteri geri bildirimi) |
| hukuk | Hukuk Müdürü | Dava / sözleşme dosyaları | Sözleşme onayı, hukuk talepleri | Almosa (hukuk, hizmet talebi), Emaar (tedarikçi ve sözleşme) |

## 7. Enerji

| Departman | Kime | Kayıt sistemi | Use case'ler | Kanıt |
|---|---|---|---|---|
| yapim-proje | Yatırım/Proje Müdürü, Yapım İşleri Müdürü | ERP / proje Excel'leri | Yapım işleri takibi, saha kurulum bütçe-maliyet, hakediş | ADM-GDZ (yapım işleri), Zorlu (şarj istasyonu bütçe, kurulum, maliyet; hakediş) |
| bakim-isletme | Bakım-Onarım / İşletme Müdürü | SCADA / bakım sistemi | Bakım-onarım iş emirleri, saha ekip talepleri | ADM-GDZ (bakım-onarım) |
| butce-finans | Bütçe ve Planlama Müdürü, Finans Müdürü | ERP | Bütçe planlama, hakediş onay ve ödeme, masraf | ADM-GDZ (planlama ve bütçe), Zorlu (hakediş, masraf) |
| risk-uyum | Risk Müdürü, İç Kontrol / Uyum Müdürü | Excel | Risk kayıtları, kriz takibi, denetim bulguları | ADM-GDZ (risk ve kriz), Almosa (GRC) |
| ik | İK Müdürü | Bordro / İK sistemi | Özlük, performans takibi, seyahat ve konaklama onayları | ADM-GDZ (özlük), Zorlu (performans, seyahat, konaklama) |
| strateji | Strateji / Kurumsal Gelişim / Dijital Dönüşüm Müdürü | Sunumlar | Strateji ve hedef takibi, dönüşüm projeleri | ADM-GDZ (strateji, dijital dönüşüm), Matlı (PMO, OKR) |

## 8. Turizm ve otelcilik

Dil: "misafir".

| Departman | Kime | Kayıt sistemi | Use case'ler | Kanıt |
|---|---|---|---|---|
| operasyon | Operasyon Müdürü, Otel Müdürü | PMS / rezervasyon sistemi | Departmanlar arası görev takibi, operasyon talepleri, sezon hazırlığı | Tatilbudur (departman arası görev, operasyon) |
| tedarik | Satın Alma / Kontrat Müdürü | ERP | Otel ve tedarikçi sözleşmeleri, tedarikçi performansı | Tatilbudur (sözleşme, tedarikçi performansı) |
| misafir-deneyimi | Misafir İlişkileri / Müşteri Hizmetleri Müdürü | CRM | Misafir talep ve şikâyetleri, departmana devir | Tatilbudur (müşteri destek) |
| teknik | Teknik Müdür | Telefon / kâğıt | Oda ve tesis arıza bildirimleri, periyodik bakım | Almosa (bakım), Bella Maison (arıza bildirimi) [KANIT ZAYIF: otelde doğrudan yok] |
| ik | İK Müdürü | Bordro / PDKS | Sezonluk işe alım, puantaj, oryantasyon | Tatilbudur (puantaj), Doğuş Çay (işe alım/oryantasyon) |
| finans | Mali İşler / Finans Müdürü | ERP | Fatura onayı, bütçe, masraf, finansal hatırlatmalar | Tatilbudur (fatura onay, bütçe, masraf) |
| satis | Satış Müdürü, B2B/Acente Satış | CRM | Teklif ve proje yönetimi, müşteri yönetimi | Tatilbudur (teklif, satış ve müşteri yönetimi) |

## 9. Özel sağlık ve sağlık turizmi

Dil: "hasta" ya da "misafir"; asla "müşteri".

| Departman | Kime | Kayıt sistemi | Use case'ler | Kanıt |
|---|---|---|---|---|
| hasta-deneyimi | Hasta Hizmetleri / Hasta Deneyimi Müdürü, Uluslararası Hasta Müdürü | HBYS / CRM | Hasta takibi, memnuniyet ve şikâyet, tedavi sonrası takip | VeraClinic (hasta takibi, hasta memnuniyeti, satış CRM) |
| kalite | Kalite Müdürü, SKS Sorumlusu | HBYS / SKS dokümanları | Hastane kalite süreçleri, SKS denetim hazırlığı, olay bildirimi | VeraClinic (hastane kalite yönetimi) |
| operasyon | Operasyon / İdari İşler Müdürü, Başhekim Yardımcısı | HBYS | Hastane planlama, operasyon talepleri, transfer ve konaklama lojistiği | VeraClinic (hastane planlama, operasyon, lojistik) |
| teknik-biyomedikal | Teknik Hizmetler / Biyomedikal Müdürü | Telefon / Excel | Cihaz arıza, teknik servis, envanter | VeraClinic (teknik servis, envanter) |
| pazarlama | Pazarlama Müdürü, Dijital Pazarlama Müdürü | Ajans araçları | Kampanya, sosyal medya, influencer, içerik ve SEO | VeraClinic (kampanya, influencer, sosyal medya, SEO) |
| ik | İK Müdürü | Bordro / İK sistemi | Özlük, prim ve hakediş, işe alım | VeraClinic (İK özlük, prim ve hakediş) |
| finans | Finans Müdürü, Faturalama Müdürü | HBYS / ERP | Kurum faturalarının tahsilat ve teslimatı | MediServ (fatura tahsilat ve teslimat), VeraClinic (finans) |

## 10. Aile holdingleri

Holding merkezine gidilir; departmanlar grup fonksiyonlarıdır.

| Departman | Kime | Kayıt sistemi | Use case'ler | Kanıt |
|---|---|---|---|---|
| strateji-pmo | Strateji / Kurumsal Gelişim Direktörü, PMO Müdürü | Sunumlar / Excel | Grup şirketlerinin hedef ve OKR takibi, PMO, dönüşüm projeleri | Matlı (PMO, OKR), Kar Porselen (master plan), Almosa (strateji) |
| yonetim-ofisi | CEO Ofisi / YK Ofisi Müdürü, Genel Sekreter | E-posta | Toplantı kararları ve aksiyon takibi, CEO/VP ofisi görevleri | Matlı (toplantı ve karar takibi), Almosa (CEO/VP ofisi) |
| ic-denetim-risk | İç Denetim Müdürü, Risk / GRC Müdürü | Excel / denetim raporları | Denetim bulgusundan aksiyona takip, GRC, risk kayıtları | Almosa (GRC, iç denetim), Matlı (iç denetim) |
| hukuk | Hukuk Müdürü / Baş Hukuk Müşaviri | Sözleşme dosyaları | Sözleşme yönetimi ve onayı, grup hukuk talepleri | Almosa (hukuk, doküman onay), Matlı (sözleşme) |
| ik | Grup İK Direktörü | İK sistemi | Grup geneli işe alım, izin, masraf ve harcırah | Altium (İK, işe alım, izin), ICYF (İK, harcırah) |
| finans-satin-alma | Grup Finans / Satın Alma Direktörü | ERP | Masraf ve avans, satın alma talepleri, tedarikçi rehberi | Altium (masraf-avans, satın alma), Matlı (tedarikçi rehberi) |

## 11. İlaç, medikal ve kozmetik

| Departman | Kime | Kayıt sistemi | Use case'ler | Kanıt |
|---|---|---|---|---|
| kalite-guvence | Kalite Güvence (KG) Müdürü, Validasyon Müdürü | QMS / LIMS | Validasyon projeleri, kalite yönetim süreçleri, sistem değişiklik takibi | Ali Raif (KG validasyon, kalite yönetimi, sistem parametre yönetimi) |
| arge | Ar-Ge Müdürü, Formülasyon Müdürü | LIMS / Excel | Ar-Ge proje takibi, stabilite çalışmaları, şablon bazlı projeler | Ali Raif (Ar-Ge, stabilite, şablon bazlı proje) |
| urun-pazarlama | Ürün Müdürü, Pazarlama Müdürü | CRM | Ürün yönetimi, lansman, kampanya | Ali Raif (pazarlama ve ürün yönetimi), Kar Porselen (portföy) |
| ruhsat | Ruhsatlandırma / Regülasyon Müdürü | Doküman dosyaları | Ruhsat dosyası adımları, resmi evrak süreleri, doküman onayı | EK Asansör (resmi evrak), Almosa (doküman onay) [KANIT ZAYIF] |
| saha-satis | Satış Müdürü, Bölge Müdürü (tıbbi tanıtım) | CRM | Saha ekip ziyaretleri ve raporları | Altılar (saha satış ekipleri) |
| ik | İK Müdürü | İK sistemi | İşe alım, eğitim, özlük | Kar Porselen (İK ve işe alım), Altium |
