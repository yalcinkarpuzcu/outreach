# Referans müşteriler ve gerçek kullanım alanları

Kaynak: "Workiom – Genel Tanıtım ve Örnek Referanslar" sunumu
(proje dosyalarında). Burada yazmayan bir kullanımı e-postada iddia etme.

## İçindekiler
1. Müşteri bazlı liste
2. Departman → kanıt dizini (hızlı arama)
3. Teyit bekleyenler

## 1. Müşteri bazlı liste

**CE LINE Lojistik** — Proje ve operasyon yönetimi · Kalite süreçleri · Satış ve
müşteri yönetimi · Envanter yönetimi · BT süreçleri · İK özlük ve izin yönetimi ·
Satın alma talep/onayları · Finansal plan, takip ve hatırlatmalar · Araç, makine
ve personel planlama · Evrak yönetimi · Teknik departman süreçleri · Sistem tanım
ve parametre yönetimi · Toplantı yönetimi · Günlük icmal/raporlama · Tamir-bakım
yönetimi · Lastik yönetimi

**Emlak Konut** — Görev yönetimi · İnşaat süreci takip sistemi · İhale ve teklif
yönetimi · Taşeron firma takibi · İç süreç otomasyonu · Müşteri geri bildirim
yönetimi · İş sağlığı ve güvenliği süreçleri · Araç bakım ve rezervasyon ·
Saha operasyon ekibi talep/onay · Ticket sistemi · Şirket içi talep yönetimi ·
Araç envanteri/sigorta, ceza, bakım takibi · İdari işler envanter · Toplantı takibi

**Emlak Konut Asansör** — Ziyaretçi takibi · BT talep · İş takibi · Araç filo
yönetimi · Demirbaş takibi · Ar-Ge proje yönetimi · İşe giriş/çıkış (özlük) ·
Fason üretim takibi · Üretim hattı izleme ve takip · Üretim planlama ve iş takibi
· Üretim talep takibi · Satış ve müşteri yönetimi · Satın alma ve tedarikçi
ziyaret takibi · 3D talep ve sipariş yönetimi · Elektrik proje ve görev yönetimi
· Seyahat talep · BT zimmet ve envanter · SAP/ERP talep yönetimi · Toplantı karar
ve aksiyon takibi · Yedek parça takibi · Müşteri iletişim ve periyodik raporlama
· Uçtan uca lojistik yönetimi · Kalite, sertifika ve resmi evrak yönetimi ·
Strateji ve kurumsal gelişim · Web sitesi form ve talep yönetimi

**ADM-GDZ Elektrik** — Kurumsal yönetim ve strateji takibi · Teknoloji ve dijital
dönüşüm · Planlama ve bütçe · Yapım işleri ve bakım-onarım takibi · BT talep ·
İK özlük · Risk yönetimi ve kriz takibi · Görev ve iş takibi

**Zorlu Enerji (Electrip Global)** — Seyahat planlama · Konaklama · Masraf takibi
· Talep/onay · Çalışan performans takibi · Hakediş talep/onay/ödeme · Görev
yönetimi · Şarj istasyonları takibi (bütçe, kurulum, maliyet)

**Ali Raif İlaç** — Yapay zekâ ve RPA proje süreçleri · Şablon bazlı proje
yönetimi · Laboratuvar veri sistemleri yükseltme ve validasyon (KG) · Sistem
parametre ve tanım yönetimi · Kalite yönetim süreçleri · Pazarlama ve ürün
yönetimi · Ar-Ge proje ve stabilite takibi · BT proje yönetimi

**Emaar AVM** — Kiracı yönetimi · Mağaza devir/teslim · Fit-out (mağaza kurulum)
yönetimi · Tedarikçi ve sözleşme takibi

**Almosa** — CEO ofisi ve VP ofisi görev yönetimi · BT helpdesk · Proje yönetimi
· Sözleşme ve kira yönetimi (Royal Mall) · Bakım yönetimi (Royal Mall) · GRC ·
Strateji yönetimi · Doküman onay · Hizmet talep yönetimi (İK, teknik ofis, hukuk)
· Hukuk süreçleri · Büyüme yönetimi · İç denetim

**Matlı Şirketler Grubu** — BT talep ve destek · Görev yönetimi · Toplantı ve
karar takibi · Sözleşme yönetimi · Kurumsal tedarikçi rehberi · Proje ve hedef
takibi · OT veri ve model yönetimi · OT proje ve ekip yönetimi · PMO · OKR · BT
ana veri · Yıllık BT hedefleri · Kurumsal kayıt yönetimi · BT iç denetim ·
Doküman yönetimi · Etkinlik yönetimi · Danışmanlık bedelleri takibi · Dijital
dönüşüm günlük iş takibi · SAP Rollout proje yönetimi

**Tatilbudur** — Departman içi/arası görev takibi · Sözleşme yönetimi ·
Tedarikçi performans yönetimi · Müşteri destek · Fatura onay · Proje ve
operasyon yönetimi · Proje/teklif yönetimi · Bütçe · Masraf · Satış ve müşteri
yönetimi · Finansal plan ve hatırlatmalar · Talep yönetimi · Evrak yönetimi ·
İK puantaj

**Doğuş Çay** — Tedarikçi yönetimi · Hakediş takibi · Filo yönetimi · İşe alım
ve oryantasyon · Dış kaynak işgücü yönetimi · Maliyet takip ve planlama ·
İç/dış kaynak performans yönetimi

**Kar Porselen (Bonna)** — Ürün geliştirme · Pazarlama ve satış · Yeni ürün
takibi · Kurumsal yönetim · İK ve işe alım · Proje yönetimi · Ürün portföy
yönetimi · Kampanya planlama · Tasarım ekibi iş takibi · KPI takibi ·
Dijitalleşme master plan / yıllık panolar · Kurumsal dönüşüm proje yönetimi ·
BT master plan

**Altium** — Yurt içi/dışı masraf ve avans · Satın alma talep · BT demirbaş
satın alma · Kartvizit talep · İK süreçleri · İşe alım · Proje ve görev
yönetimi · İzin yönetimi · Demirbaş yönetimi

**VeraClinic** — Satış CRM · Operasyon yönetimi · Müşteri (hasta) takibi · İK ve
özlük · Prim ve hakediş · Görev yönetimi · Satış performans · Teknik servis ·
Kreatif ve tasarım iş takibi · SEO ve içerik · Proje yönetimi · Hasta
memnuniyeti takibi · Pazarlama ve kampanya · Prodüksiyon ekibi iş takibi · Web
geliştirme · Hizmet yönetimi · İş geliştirme · Finans · Lojistik · Abonelik
takibi · Hastane planlama · Hastane kalite yönetimi · Envanter · E-posta
pazarlama · Marka yönetimi · Influencer planlama · Sosyal medya · Diş kliniği
operasyonları

**Ebrar Unlu Mamulleri** — İK işe alım · Avans takibi · Görev yönetimi · Şube
teknik arıza talep ve servis yönetimi · Satın alma · Teklif toplama ve geri
bildirim · Araç filosu (sigorta, muayene) · Online sipariş yönetimi · Kurumsal
abonelikler · Sosyal medya planlaması · Doküman yönetimi

**Bella Maison** — Görev yönetimi · Ticket/arıza bildirimi · BT yönetimi ·
Müşteri destek · Demirbaş takibi

**Altılar Ticaret** — Saha satış ekipleri · CRM · Müşteri memnuniyeti · Stok ·
İK · Satın alma takibi · Denetim · Sigorta takibi

**ICYF** — İK · İzin takibi · Proje yönetimi · Masraf ve harcırah · Görev
yönetimi · Seyahat planlama ve onay · Paydaş yönetimi

**Unifonic** — Müşteri tanıma (KYC) · Gönderici kimliği doğrulama

**MediServ** — Fatura tahsilat yönetimi · Fatura teslimat yönetimi

Listede adı geçip kullanım detayı olmayanlar: CB Yatırım Ofisi, Atasay.

## 2. Departman → kanıt dizini

| Departman | En güçlü kanıt | Destek kanıtı |
|---|---|---|
| Operasyon / planlama | CE LINE (operasyon, araç-makine-personel planlama, günlük icmal) | Tatilbudur, VeraClinic |
| Filo / araç | CE LINE (tamir-bakım, lastik) | Emlak Konut (araç sigorta, ceza, bakım), Doğuş Çay, Ebrar, EK Asansör |
| Bakım / teknik servis | CE LINE (teknik departman, tamir-bakım) | Almosa (Royal Mall bakım), ADM-GDZ (bakım-onarım), EK Asansör (yedek parça), VeraClinic |
| Şube / mağaza arıza | Ebrar (şube teknik arıza ve servis) | Bella Maison (ticket/arıza) |
| Kalite | EK Asansör (kalite, sertifika, resmi evrak) | CE LINE, Ali Raif (kalite yönetimi, validasyon), VeraClinic (hastane kalite) |
| Denetim | Altılar (denetim) | Almosa (iç denetim), Matlı (iç denetim) |
| Satın alma / tedarik | Doğuş Çay (tedarikçi yönetimi, hakediş) | Ebrar (teklif toplama), CE LINE, Altium, Tatilbudur (tedarikçi performansı), EK Asansör (tedarikçi ziyaret) |
| Üretim | EK Asansör (üretim planlama, hat izleme, fason, üretim talep) | — |
| Ar-Ge / ürün geliştirme | Ali Raif (Ar-Ge, stabilite) | Kar Porselen (ürün geliştirme, yeni ürün), EK Asansör (Ar-Ge, 3D talep) |
| İK | Doğuş Çay (işe alım/oryantasyon, dış kaynak işgücü) | CE LINE, Tatilbudur (puantaj), Ebrar, Altium, ICYF, VeraClinic (prim/hakediş) |
| Finans | Tatilbudur (fatura onay, bütçe, masraf) | Zorlu (hakediş), MediServ (fatura tahsilat/teslimat), Altium (masraf-avans), Doğuş Çay (maliyet) |
| Satış / saha satış | Altılar (saha satış ekipleri) | VeraClinic (satış CRM, performans), CE LINE |
| Müşteri hizmetleri / deneyim | Tatilbudur (müşteri destek) | Bella Maison, VeraClinic (hasta memnuniyeti), Emlak Konut (geri bildirim) |
| Pazarlama | VeraClinic (kampanya, sosyal medya, influencer) | Kar Porselen (kampanya, portföy), Ali Raif |
| İnşaat / proje | Emlak Konut (inşaat takibi, ihale, taşeron) | ADM-GDZ (yapım işleri), Zorlu (şarj istasyonu kurulum) |
| İSG | Emlak Konut | — |
| AVM / kiralama | Emaar AVM (kiracı, devir-teslim, fit-out) | Almosa (kira, Royal Mall) |
| Strateji / PMO / CEO ofisi | Matlı (PMO, OKR) | Almosa (CEO/VP ofisi, strateji), ADM-GDZ, Kar Porselen |
| Risk / uyum / hukuk | Almosa (GRC, hukuk, iç denetim) | ADM-GDZ (risk ve kriz), Matlı |
| İdari işler | Emlak Konut (idari envanter, ticket) | Altium (demirbaş), EK Asansör (ziyaretçi) |

## 3. Teyit bekleyenler [TEYİT]

- **Renault Türkiye** — 13 bölgelik servis ağı denetimleri (web sitesi vakası;
  sunumdaki referans listesinde yok). Yalçın onaylamadan kullanma.
- **Plasto** — tüm departmanlar, %50 hız artışı (web sitesi vakası). Aynı kural.
