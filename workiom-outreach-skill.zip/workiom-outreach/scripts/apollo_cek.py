#!/usr/bin/env python3
"""
apollo_cek.py - Workiom outreach: Apollo'dan sektor + departman bazli kontak ceker.

Kullanim:
  export APOLLO_API_KEY=xxxx
  python scripts/apollo_cek.py --sektor lojistik
  python scripts/apollo_cek.py --sektor lojistik --departman filo-bakim --max-sayfa 2
  python scripts/apollo_cek.py --sektor lojistik --zenginlestir --max-zenginlestirme 50
  python scripts/apollo_cek.py --sektor lojistik --kuru-calisma   # API'ye gitmez, istegi gosterir

Cikti: cikti/<sektor>/<YYYY-MM-DD>/
  kontaklar_<departman>.csv   (departman basina bir dosya)
  ozet.md                      (departman basina kisi ve firma sayilari)

Notlar:
- Arama (mixed_people/search) e-posta kredisi harcamaz; e-postalar cogu zaman
  kilitli doner. --zenginlestir ile people/bulk_match cagrilir ve KREDI HARCAR.
- Apollo endpoint ve parametre adlari zamanla degisebilir. Ilk calistirmada
  hata alirsan https://docs.apollo.io adresinden "People Search" ve
  "Bulk People Enrichment" sayfalarini kontrol et; sabitler asagida.
- Bir kisi birden fazla departman aramasina dusebilir; ilk eslesen departmanda
  tutulur (config'deki departman sirasi oncelik sirasidir).
"""
import argparse, csv, datetime, json, os, sys, time
from pathlib import Path

try:
    import requests
except ImportError:
    sys.exit("requests kurulu degil: pip install requests")

API_TABANI = "https://api.apollo.io/api/v1"
ARAMA_YOLU = "/mixed_people/search"
ZENGINLESTIRME_YOLU = "/people/bulk_match"
SAYFA_BASINA = 100
BEKLEME_SN = 1.2  # rate limit icin

KOK = Path(__file__).resolve().parent.parent
CONFIG = KOK / "config" / "sektorler.json"

ALANLAR = ["departman", "hitap", "ad", "soyad", "unvan", "firma", "web_sitesi",
           "calisan_sayisi", "sehir", "linkedin", "email", "email_durumu",
           "kisisellestirme", "apollo_id", "firma_apollo_id"]


def basliklar(anahtar):
    return {"Content-Type": "application/json", "Cache-Control": "no-cache",
            "X-Api-Key": anahtar}


def config_yukle(sektor):
    veri = json.loads(CONFIG.read_text(encoding="utf-8"))
    if sektor not in veri:
        secenekler = [k for k in veri if not k.startswith("_") and k != "varsayilan"]
        sys.exit(f"Sektor bulunamadi: {sektor}. Secenekler: {', '.join(secenekler)}")
    return veri["varsayilan"], veri[sektor]


def arama_govdesi(varsayilan, sektor_cfg, unvanlar, sayfa):
    return {
        "person_titles": unvanlar,
        "include_similar_titles": True,
        "person_seniorities": varsayilan["kidem"],
        "organization_locations": varsayilan["lokasyon"],
        "organization_num_employees_ranges": varsayilan["calisan_araliklari"],
        "q_organization_keyword_tags": sektor_cfg["firma_anahtar_kelimeleri"],
        "page": sayfa,
        "per_page": SAYFA_BASINA,
    }


def ara(anahtar, govde):
    for deneme in range(3):
        r = requests.post(API_TABANI + ARAMA_YOLU, headers=basliklar(anahtar),
                          json=govde, timeout=60)
        if r.status_code == 429:
            time.sleep(10 * (deneme + 1)); continue
        if r.status_code != 200:
            sys.exit(f"Apollo arama hatasi {r.status_code}: {r.text[:500]}")
        return r.json()
    sys.exit("Apollo rate limit: 3 denemede de 429 dondu.")


def kisi_satiri(departman, p):
    org = p.get("organization") or {}
    email = p.get("email") or ""
    if "not_unlocked" in email:
        email = ""
    return {
        "departman": departman, "hitap": "",
        "ad": p.get("first_name") or "", "soyad": p.get("last_name") or "",
        "unvan": p.get("title") or "", "firma": org.get("name") or "",
        "web_sitesi": org.get("website_url") or org.get("primary_domain") or "",
        "calisan_sayisi": org.get("estimated_num_employees") or "",
        "sehir": p.get("city") or "", "linkedin": p.get("linkedin_url") or "",
        "email": email, "email_durumu": p.get("email_status") or "",
        "kisisellestirme": "", "apollo_id": p.get("id") or "",
        "firma_apollo_id": org.get("id") or p.get("organization_id") or "",
    }


def zenginlestir(anahtar, satirlar, limit):
    hedef = [s for s in satirlar if not s["email"] and s["apollo_id"]][:limit]
    for i in range(0, len(hedef), 10):
        grup = hedef[i:i + 10]
        govde = {"details": [{"id": s["apollo_id"]} for s in grup],
                 "reveal_personal_emails": False}
        r = requests.post(API_TABANI + ZENGINLESTIRME_YOLU, headers=basliklar(anahtar),
                          json=govde, timeout=60)
        if r.status_code != 200:
            print(f"  ! zenginlestirme hatasi {r.status_code}: {r.text[:200]}"); break
        eslesme = {m.get("id"): m for m in (r.json().get("matches") or []) if m}
        for s in grup:
            m = eslesme.get(s["apollo_id"])
            if m and m.get("email"):
                s["email"] = m["email"]; s["email_durumu"] = m.get("email_status") or ""
        time.sleep(BEKLEME_SN)
    return len(hedef)


def main():
    ap = argparse.ArgumentParser(description="Apollo'dan departman bazli kontak cek")
    ap.add_argument("--sektor", required=True)
    ap.add_argument("--departman", help="Tek departman (varsayilan: hepsi)")
    ap.add_argument("--max-sayfa", type=int, default=3, help="Departman basina sayfa (x100 kisi)")
    ap.add_argument("--firma-basina-max", type=int, default=2, help="Ayni firmadan ayni departmanda en fazla kisi")
    ap.add_argument("--zenginlestir", action="store_true", help="E-postalari ac (KREDI HARCAR)")
    ap.add_argument("--max-zenginlestirme", type=int, default=100)
    ap.add_argument("--kuru-calisma", action="store_true")
    a = ap.parse_args()

    varsayilan, cfg = config_yukle(a.sektor)
    departmanlar = cfg["departmanlar"]
    if a.departman:
        if a.departman not in departmanlar:
            sys.exit(f"Departman yok: {a.departman}. Secenekler: {', '.join(departmanlar)}")
        departmanlar = {a.departman: departmanlar[a.departman]}

    if a.kuru_calisma:
        for d, unvanlar in departmanlar.items():
            print(f"[{d}] POST {API_TABANI + ARAMA_YOLU}")
            print(json.dumps(arama_govdesi(varsayilan, cfg, unvanlar, 1), ensure_ascii=False, indent=2))
        return

    anahtar = os.environ.get("APOLLO_API_KEY")
    if not anahtar:
        sys.exit("APOLLO_API_KEY ortam degiskeni tanimli degil.")

    klasor = KOK / "cikti" / a.sektor / datetime.date.today().isoformat()
    klasor.mkdir(parents=True, exist_ok=True)
    gorulen = set()
    ozet = []

    for d, unvanlar in departmanlar.items():
        print(f"[{d}] araniyor...")
        satirlar, firma_sayac = [], {}
        for sayfa in range(1, a.max_sayfa + 1):
            yanit = ara(anahtar, arama_govdesi(varsayilan, cfg, unvanlar, sayfa))
            kisiler = (yanit.get("people") or []) + (yanit.get("contacts") or [])
            for p in kisiler:
                pid = p.get("id")
                if not pid or pid in gorulen:
                    continue
                s = kisi_satiri(d, p)
                fk = s["firma_apollo_id"] or s["firma"]
                if firma_sayac.get(fk, 0) >= a.firma_basina_max:
                    continue
                firma_sayac[fk] = firma_sayac.get(fk, 0) + 1
                gorulen.add(pid); satirlar.append(s)
            toplam_sayfa = (yanit.get("pagination") or {}).get("total_pages") or 1
            time.sleep(BEKLEME_SN)
            if sayfa >= toplam_sayfa:
                break
        acilan = zenginlestir(anahtar, satirlar, a.max_zenginlestirme) if a.zenginlestir else 0
        dosya = klasor / f"kontaklar_{d}.csv"
        with dosya.open("w", newline="", encoding="utf-8-sig") as f:
            w = csv.DictWriter(f, fieldnames=ALANLAR); w.writeheader(); w.writerows(satirlar)
        epostali = sum(1 for s in satirlar if s["email"])
        ozet.append((d, len(satirlar), len(firma_sayac), epostali, acilan))
        print(f"  {len(satirlar)} kisi, {len(firma_sayac)} firma, {epostali} e-postali -> {dosya.name}")

    with (klasor / "ozet.md").open("w", encoding="utf-8") as f:
        f.write(f"# {cfg['ad']} - Apollo cekimi {datetime.date.today().isoformat()}\n\n")
        f.write("| Departman | Kisi | Firma | E-postali | Zenginlestirilen |\n|---|---|---|---|---|\n")
        for d, k, fr, e, z in ozet:
            f.write(f"| {d} | {k} | {fr} | {e} | {z} |\n")
    print(f"\nTamam: {klasor}")


if __name__ == "__main__":
    main()
