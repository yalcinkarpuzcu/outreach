---
name: workiom-outreach
description: "Workiom için outbound outreach içeriği üretirken MUTLAKA kullan: dikey (sektör içindeki departman bazlı) e-posta sekansları, yatay (patron/CEO/GM) sekanslar, Apollo'dan kontak çekme ve departmana ayırma, kişiselleştirme cümleleri, LinkedIn ve telefon scriptleri, itiraz cevapları. Kullanıcı sadece bir sektör adı söylese bile ('lojistik', 'perakende yap', 'üretim için hazırla') bu skill tetiklenir. Workiom'un AI-First Workspace konumlandırmasını ve buradaki üslup kurallarını zorunlu kılar. Sadece Workiom içindir."
---

# Workiom Outreach

Bu skill Workiom'un bütün soğuk outreach içeriğinin üslubunu, yapısını ve
üretim akışını belirler. Üslup bu dosyada; malzeme `references/` altında;
kontak çekme `scripts/apollo_cek.py` ile.

Okuma sırası (her yeni sektörde):
1. Bu dosya (kurallar)
2. `references/departman-matrisi.md` → istenen sektörün bölümü
3. `references/referanslar.md` → kanıt olarak kullanılacak müşteriler
4. `references/ornek-sekans.md` → üslup çıpası; yazmadan önce mutlaka oku

## 1. Temel konumlandırma (her içerikte sabit)

- **Tanım:** Workiom bir AI-First Workspace. Sizi AI-first bir şirkete
  dönüştüren, bunu büyük bir yatırım yapmadan yapabileceğiniz platform.
- **Yer tanımı:** "Sistemleriniz ne olduğunu kaydediyor, Workiom bundan sonra
  ne olacağını yönetiyor." Kritik sistemlerin (ERP, CRM, filo, HBYS, PMS...)
  etrafındaki, arasındaki ve üstündeki iş.
- **Tek anlatı, altı parça** (özellik gibi sayma, tek mimarinin parçası olarak
  geçir): Apps, Mila (asistan), Agents (bir görevin sahibi kişi, ekip ya da AI
  ajanı olabilir), MCP (mevcut AI araçlarını bağla), Vibe Apps (bayi/tedarikçi/
  müşteri portalı), Yönetişim (yetkiler, onay kapıları, activity log).
- **Neden şimdi:** Ekipler LLM'leri bireysel kullanıyor; ortak know-how
  oluşmuyor, kişi ayrılınca işin izi kalmıyor. Workiom ekiplerin ve AI'ın aynı
  veri üzerinde birlikte çalıştığı yer.
- **Fiyat dili:** kullanıcı başına; süreç ya da uygulama sayısı bedeli
  değiştirmez. Kurulum ya da altyapı yatırımı yok. İlk adım ücretsiz pilot.

## 2. Yapmayacaklarımız (ihlal = içerik yanlış)

- "Neye ihtiyacınız var?" diye açmak.
- No-code / low-code / BPM tartışmasına girmek; teknik ifadeyle kapı açmak.
- Özellik listesi saymak; Workiom'u tek süreçlik bir araç gibi anlatmak.
- IT'yi / CIO'yu hedef almak; "IT'yi beklemeden" demek.
- Sektör know-how'ı iddia etmek; "sektörünüzde ilk siz olun" demek.
- İlk adımı büyük bir proje gibi göstermek.
- **Jenerik departman içeriği yazmak.** "Süreçlerinizi yönetin" gibi her
  departmana gidebilecek cümle = hata.

## 3. İki kanal

### Yatay — basit tut
Patron, kurucu, YK Başkanı, CEO, GM'ye gider. Sektörden bağımsız, kısa:
AI bireysel kullanımdan ortak çalışma alanına, kurumsallaşma, kontrol,
öngörülebilir maliyet. Açılış sorusu: "Ekipleriniz AI'ı tek başına mı
kullanıyor?" Kurucu/aile şirketinde: "İşler kişilere mi bağlı, sisteme mi?"

### Dikey — sektör DEĞİL, departman
**En önemli kural:** Bir sektöre tek bir dikey sekans gitmez. Kullanıcı
"lojistik" dediğinde lojistikteki HER hedef departman için AYRI liste ve AYRI
sekans üretilir. Matriste 7 departman varsa 7 sekans çıkar.

Her departman sekansı:
- Sadece o sektördeki o departmanın kendi işinden konuşur (matristeki use case'ler).
- O departmanın kullandığı kayıt sistemini adıyla anar (filo sistemi, WMS,
  HBYS, ERP'nin satın alma modülü...) ve "ondan sonra kalan işi" tarif eder.
- O departmana en yakın referans kanıtını kullanır; kanıt departman
  düzeyinde olmalı ("CE LINE tamir-bakım ve lastik yönetimini..."), şirket
  düzeyinde değil.
- Departmanın diliyle konuşur (perakendede "mağaza", sağlıkta "hasta/misafir",
  kalitede "uygunsuzluk", bakımda "iş emri").

Test: Bir departmanın D1'ini aynı sektörün başka departmanına gönderebiliyorsan
yeterince özel değildir, yeniden yaz.

## 4. Sekans yapısı (her departman için 3 e-posta)

Resmi dil. D1, D2 ve D3'ün hepsi aynı giriş satırıyla açılır:
"Merhaba {Hitap}, nasılsınız? Her şey yolundadır umarım 🙏🏻"
({Hitap} = "Ahmet Bey" / "Ayşe Hanım").
D1'in ikinci satırı hesaba özel tek kişiselleştirme cümlesi: `{Kişiselleştirme}`.
İmza Apollo'dan gelir, e-postaya yazılmaz. Her gövde 90–140 kelime.

- **D1 · Gün 2 · departmana özel:** Departmanın kayıt sisteminin tuttuğu şey →
  ondan sonra e-posta/telefon/Excel arasında kalan 2–3 somut iş → Workiom'un
  AI-First Workspace tanımı + yer cümlesi → departman düzeyinde referans kanıtı
  → departmana özel kapanış: "{departman alanı}ndaki bir sürecinizle ilk
  uygulamayı 30 dakikalık bir görüşmede birlikte kuralım mı?"
- **D2 · Gün 6 · AI açısı (Re: D1 konusu):** Ekipte LLM bireysel kullanılıyor,
  çözüm ortak bir yerde kalmıyor (departmanın örneğiyle) → Mila'ya departmana
  özgü bir soru sorma ve cevaptan görev atama → tekrarlayan takibi bir AI
  ajanına bırakma + yönetişim (neye yetkisi olduğunu siz belirliyorsunuz) →
  departmana özgü açık soru.
- **D3 · Gün 13 · küçük başlangıç ve kapanış:** "Büyük bir proje değil, tek bir
  süreç:" + departmandan 3 aday süreç → toplantıda birlikte kurma + ücretsiz
  pilot → referansta alanın departmandan diğerlerine yayıldığı cümle →
  kullanıcı başına fiyat → "{Gün} veya {gün} 30 dakikanız olur mu? Şu an
  önceliğiniz değilse bu konudaki son e-postam; ileride gündeme gelirse bu
  mesaja cevap vermeniz yeterli."

Konu satırları kısa (3–6 kelime), departmanın gerçek bir anını anlatır
("Bakım talebi hangi onayda?", "Mağaza denetiminden sonra"). Clickbait yok.

Apollo'ya aktarılacak hali: `{Hitap}` → `{{hitap}}`, `{Kişiselleştirme}` →
`{{kisisellestirme}}`, `{Şirket}` → `{{company}}` (özel alan adları
`references/apollo-akisi.md`'de).

## 5. Kurucu/aile segmenti

50–1000 beyaz yakalı, kurucu ya da aile yönetimli şirketlerde: patrona yatay
kanalın kurucu versiyonu, ilgili müdürlere departman sekansları; ikisi hesap
içinde paralel. Kurucu mesajı kurumsallaşma, kontrol ve öngörülebilir maliyet
üzerinedir.

## 6. Doğruluk kuralları

- Referans ve use case uydurma; sadece `references/referanslar.md`'de yazanı
  kullan. Departmana birebir kanıt yoksa en yakınını kullan ve çıktıda
  "[KANIT ZAYIF]" diye işaretle.
- "[TEYİT]" işaretli referansları (Renault Türkiye, Plasto) Yalçın onay
  vermeden e-postaya koyma.
- D2'deki AI akışları ürünün genel yetenekleridir; referansta birebir böyle
  kurulduğunu iddia etme.
- Kişiselleştirme cümlesinde sadece Apollo verisinden ya da firmanın web
  sitesinden doğrulanabilen bir bilgi kullan; doğrulayamıyorsan boş bırak.

## 7. Üretim akışı

Kullanıcı bir sektör adı verdiğinde `references/apollo-akisi.md`'deki 6 adımı
izle. Onay kapısı zorunlu: hiçbir şey Yalçın "onaylıyorum" demeden "hazır"
sayılmaz; gönderimi her zaman Yalçın Apollo'dan yapar.
