# workiom-outreach — kurulum

## Klasör
```
workiom-outreach/
├── SKILL.md                      üslup ve kurallar (skill'in kalbi)
├── PROJE_TALIMATI.md             projenin Instructions alanına yapıştırılacak metin
├── references/
│   ├── departman-matrisi.md      11 sektör × 77 departman: kime, use case, kanıt
│   ├── referanslar.md            müşteri bazlı gerçek kullanımlar + departman→kanıt dizini
│   ├── ornek-sekans.md           üslup çıpası (Lojistik · Filo ve Bakım, D1-D3)
│   └── apollo-akisi.md           sektör adından onaya 6 adım
├── scripts/apollo_cek.py         Apollo'dan departman bazlı kontak çekme
├── config/sektorler.json         Apollo filtreleri (unvanlar, firma anahtar kelimeleri)
└── kaynaklar/                    Workiom positioning ve referans PDF'leri
```

## Kurulum (Workiom tarafındaki Claude)
1. Klasörü skill olarak yükle (zip'i Skills bölümüne ya da Claude Code'da
   `.claude/skills/workiom-outreach/` altına).
2. `kaynaklar/` içindeki PDF'leri projenin dosyalarına da ekle.
3. `PROJE_TALIMATI.md` metnini projenin talimat alanına yapıştır.
4. Apollo → Settings → Integrations → API'den bir anahtar al, çalışma
   ortamında `APOLLO_API_KEY` olarak tanımla. Script'in Apollo'ya erişmesi için
   ortamın internet izninde `api.apollo.io` açık olmalı.
5. İlk test: `python scripts/apollo_cek.py --sektor lojistik --kuru-calisma`,
   sonra `--departman filo-bakim --max-sayfa 1` ile küçük gerçek çekim.

## Kullanım
"lojistik" → plan → çekim → sekanslar → onay paketi → Apollo dosyaları.
Gönderimi sen Apollo'dan yaparsın.

## İlk çalıştırmada kontrol et
- Apollo endpoint/parametre adları değişmiş olabilir (`scripts/apollo_cek.py`
  başındaki sabitler). Hata mesajı bunu söyler.
- `q_organization_keyword_tags` Türkçe firmalarda dar kalabilir; ilk çekimde
  sonuç azsa `config/sektorler.json`'a anahtar kelime ekle.
- Apollo'da özel alanların (`hitap`, `kisisellestirme`) sekans değişkeni olarak
  göründüğünü bir test kontağıyla doğrula.
